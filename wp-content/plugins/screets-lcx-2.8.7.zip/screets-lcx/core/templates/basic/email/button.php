<div><!--[if mso]>
  <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="<?php echo $link; ?>" style="height:45px;v-text-anchor:middle;width:150px;" arcsize="10%" stroke="f" fillcolor="<?php echo $color; ?>">
    <w:anchorlock/>
    <center>
  <![endif]-->
      <a href="<?php echo $link; ?>"
style="background-color:<?php echo $color; ?>;border-radius:<?php echo $radius; ?>color:#ffffff;display:inline-block;font-family:sans-serif;font-size:16px;font-weight:bold;line-height:45px;text-align:center;text-decoration:none;-webkit-text-size-adjust:none;"><?php echo $title; ?></a>
  <!--[if mso]>
    </center>
  </v:roundrect>
<![endif]--></div>