<?php
    
    /**
    * 
    * General compatibility class to be used for groups of plugins
    * 
    */
    
    if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
    
    class WPH_conflict_handle_General
        {
                        
            static function init()
                {
                    //nothing at the moment
                }                        
           
            
                            
        }
        
        
    WPH_conflict_handle_General::init();


?>